/*Description: 
 *
 * Functions to handle and get sensor data
*/

#include "DHT.h"

void getSensorValues(DHT *dht, float *humidty, float *temp, float *moisture);

